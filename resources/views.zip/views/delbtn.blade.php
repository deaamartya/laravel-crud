<a href="{{ url($dellink.'/delete/'.$id) }}" class="btn btn-danger btn-icon-split btn-sm delete-confirm">
    <span class="icon text-white-30">
          <i class="material-icons">delete</i>
        </span>
    <span class="text">Delete</span>
</a>