<a href="{{ url($dellink.'/restore/'.$id) }}" class="btn btn-success btn-icon-split btn-sm res-confirm">
    <span class="icon text-white-30">
          <i class="material-icons">restore_from_trash</i>
        </span>
    <span class="text">Restore</span>
</a>