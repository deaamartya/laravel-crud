<?php $__env->startSection('kontent'); ?>
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
		  		<h3 class="m-0 font-weight-bold text-primary">Tambahkan Data Kategori</h3>
		    </div>
			<div class="card-body">

				<form method="post" action="<?php echo e(route('categories.store')); ?>" id="catForm">
					<?php echo csrf_field(); ?>
					<div class="col-2" style="margin-bottom: 10px; padding-left: 0px;">
						<?php $__env->startComponent('components.formfield'); ?>
						    <?php $__env->slot('icon'); ?> dns <?php $__env->endSlot(); ?>
						    <?php $__env->slot('type'); ?> text <?php $__env->endSlot(); ?>
						    <?php $__env->slot('onkey'); ?> return lettersOnlySpace(event) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('name'); ?> category_name <?php $__env->endSlot(); ?>
						    <?php $__env->slot('req'); ?> true <?php $__env->endSlot(); ?>
						    <?php $__env->slot('maxl'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('max'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('value'); ?> <?php $__env->endSlot(); ?>
						    <?php $__env->slot('label'); ?> Nama Kategori <?php $__env->endSlot(); ?>
						    <?php $__env->slot('help'); ?> Masukkan huruf(A-Z) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('char'); ?> 0 / 50 <?php $__env->endSlot(); ?>
					    <?php echo $__env->renderComponent(); ?>
					</div>
					<h6 class="m-10 font-italic text-danger">(*) Wajib diisi</h3>
					<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inputmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\crud\resources\views//cat/form.blade.php ENDPATH**/ ?>