<?php $__env->startSection('judultable','Detail Penjualan'); ?>

<?php $__env->startSection('btn-insert'); ?>
<a href="<?php echo e(route('saledet.create')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>Nama Product</th>
  <th>Jumlah</th>
  <th>Harga Jual</th>
  <th>Diskon</th>
  <th>Total Harga</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $saledets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c -> nota_id); ?></td>
	<td><?php echo e($c -> product_name); ?></td>
  <td><?php echo e($c -> quantity); ?></td>
  <td><?php echo e($c -> selling_price); ?></td>
  <td><?php echo e($c -> discount); ?></td>
  <td><?php echo e($c ->total_price); ?></td>
  <td>

    <a href="/saledet/edit/<?php echo e($c ->nota_id); ?>/<?php echo e($c ->product_id); ?>" class="btn btn-warning btn-icon-split btn-sm">
        <span class="icon text-white-30">
          <i class="material-icons">edit</i>
        </span>
        <span class="text">Edit</span>
    </a>
    <button class="btn btn-danger btn-icon-split btn-sm" type="button" data-toggle="modal" data-target=".deleteModal<?php echo e($c ->nota_id); ?><?php echo e($c ->product_id); ?>">
      <span class="icon text-white-30">
              <i class="material-icons">delete</i>
            </span>
            <span class="text">Delete</span>
    </button>

    <div class="modal fade deleteModal<?php echo e($c ->nota_id); ?><?php echo e($c ->product_id); ?>" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Hapus Detail Penjualan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Apakah anda yakin ingin menghapus detail penjualan id nota <?php echo e($c ->nota_id); ?> dan produk <?php echo e($c -> product_name); ?> ?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" style="padding: 2px 6px" data-dismiss="modal">Cancel</button>
          <form action="/saledet/destroy/<?php echo e($c ->nota_id); ?>/<?php echo e($c ->product_id); ?>" method="get" style="width: 200px;">
          <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary btn-sm" style="padding: 2px 6px">
              Ya
            </button>
        </form>
          </div>
        </div>
      </div>
      </div>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\crud\resources\views/saledet/list.blade.php ENDPATH**/ ?>