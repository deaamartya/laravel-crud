<?php $__env->startSection('headlink'); ?>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="<?php echo e(asset('/materialdesign/material-components-web.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/alert/sweetalert2.min.css')); ?>">
<style type="text/css">
	@use  "@material/textfield/mdc-text-field";
</style>
<?php echo $__env->yieldContent('tambahlink'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

	<?php echo $__env->yieldContent('kontent'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom'); ?>
<?php echo $__env->yieldContent('bottomlink'); ?>
<script src="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<script>
const textFields = document.querySelectorAll('.mdc-text-field');
for (const textField of textFields) {
  mdc.textField.MDCTextField.attachTo(textField);
}

function lettersOnlySpace(evt) {
evt = (evt) ? evt : event;
var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :
  ((evt.which) ? evt.which : 0));
if (charCode > 32 && (charCode < 65 || charCode > 90) &&
  (charCode < 97 || charCode > 122 )) {
  return false;
}
return true;
}

function numOnly(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function lettersOnly(evt) {
   evt = (evt) ? evt : event;
   var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :
      ((evt.which) ? evt.which : 0));
   if (charCode > 31 && (charCode < 65 || charCode > 90) &&
      (charCode < 97 || charCode > 122)) {
      return false;
   }
   return true;
 }
 function lettersNum(evt) {
   evt = (evt) ? evt : event;
   var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :
      ((evt.which) ? evt.which : 0));
   if (charCode > 31 && (charCode < 65 || charCode > 90) ||
      (charCode < 97 || charCode > 122)) {
      return false;
   }
   return true;
 }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/inputmaster.blade.php ENDPATH**/ ?>