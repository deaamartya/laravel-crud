<body>
    <input data-inputmask="'alias': 'decimal', 'groupSeparator': ','" style="text-align: right;">
    <script src="https://code.jquery.com/jquery-1.10.0.min.js"></script>
    <script src="https://rawgit.com/RobinHerbots/Inputmask/5.x/dist/jquery.inputmask.js"></script>
</body><?php /**PATH C:\xampp1\htdocs\crud\resources\views//sale/total.blade.php ENDPATH**/ ?>