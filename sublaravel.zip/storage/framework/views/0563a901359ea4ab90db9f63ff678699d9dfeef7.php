<?php $__env->startSection('Judul','Home'); ?>
<?php $__env->startSection('konten'); ?>
<div class="card shadow mb-4" style="padding: 50px;">
<div class="card-body">
  <div class="text-center">
    <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 50rem;" src="img/welcome.svg" alt="">
  </div>
  <h1 class="text-center font-weight-bold">Welcome Back! </h1>
  <h2 class="text-center font-weight-light"><?php echo e(@session('name')); ?> <?php echo e(@session('last_name')); ?></h2>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>