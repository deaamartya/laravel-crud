<?php $__env->startSection('headlink'); ?>
	<link href="/admin/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <style type="text/css">
    .btn-group-sm > .btn-icon-split.btn .icon, .btn-icon-split.btn-sm .icon {
      padding: 2px 5px;
    };
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h3 class="m-0 font-weight-bold text-primary">Invoice #<?php echo e($sale -> nota_id); ?></h3>
    </div>
    <div class="card-body">
      <div class="row">
        <h4>Nama Pembeli : <?php echo e($sale -> u_name); ?></h4>
      </div>
      <div class="row">
        <h4>Nama Karyawan : <?php echo e($sale -> c_name); ?></h4>
      </div>
      <div class="row">
        <h4>Tanggal Pembelian : <?php echo e($sale -> nota_date); ?></h4>
      </div>
      <div class="row">
        <table class="table" width="100%">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama Produk</th>
              <th>Jumlah</th>
              <th>Harga</th>
              <th>Diskon</th>
              <th>Total Harga</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $saledetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($c -> product_id); ?></td>
                <td><?php echo e($c -> product_name); ?></td>
                <td><?php echo e($c -> quantity); ?></td>
                <td><?php echo e($c -> selling_price); ?></td>
                <td><?php echo e($c -> discount); ?></td>
                <td><?php echo e($c -> total_price); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <div class="row">
        <div class="col align-self-end">
          <h6>Total Payment : Rp. <?php echo e($sale -> total_payment); ?></h6>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bottom'); ?>
<script src="/admin/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="/admin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="/admin/js/demo/datatables-demo.js"></script>
<?php echo $__env->yieldContent('bottomlink'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\crud\resources\views/sale/show.blade.php ENDPATH**/ ?>