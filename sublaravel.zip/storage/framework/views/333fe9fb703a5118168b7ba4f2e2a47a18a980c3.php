<?php $__env->startSection('Judul','Data Kategori'); ?>
<?php $__env->startSection('judultable','Kategori'); ?>

<?php if(session('type') == 4): ?>
  <?php $__env->startSection('btn-insert'); ?>
  <a href="<?php echo e(route('categories.create')); ?>">
    <button class="btn btn-primary">Tambah Kategori</button>
  </a>
  <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>Name</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c -> category_id); ?></td>
	<td><?php echo e($c -> category_name); ?></td>
  <td>
    <?php if(session('type') == 4): ?>
      <?php echo $__env->make('editbtn', 
      array(
      'editlink' => 'categories.edit',
      'id' => $c -> category_id), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(session('type') == 1): ?>
    <?php echo $__env->make('delbtn', 
    array(
    'id' => $c -> category_id,
    'dellink' => 'categories'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahankonten'); ?>
  <?php if(session('deleted')): ?>
    <script>
      Swal.fire(
        'Delete Success!',
        "Kategori <?php echo e(@session('deleted')); ?> telah dihapus",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('inserted')): ?>
    <script>
      Swal.fire(
        'Insert Success!',
        "Kategori <?php echo e(@session('inserted')); ?> berhasil ditambahkan",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('edited')): ?>
    <script>
      Swal.fire(
        'Edit Success!',
        "Data kategori dengan ID <?php echo e(@session('edited')); ?> berhasil diubah",
        'success'
      )
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomlink'); ?>
<script>
$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    Swal.fire({
    title: 'Apakah kamu yakin?',
    text: "Kategori yang dihapus tidak dapat dikembalikan!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ya, Saya Yakin!',
    cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            window.location.href = url;
        }
        else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Kategori tidak dihapus',
          'error'
        )
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/cat/list.blade.php ENDPATH**/ ?>