<a href="<?php echo e(route( $editlink , $id)); ?>" class="btn btn-warning btn-icon-split btn-sm">
        <span class="icon text-white-30">
          <i class="material-icons">edit</i>
        </span>
        <span class="text">Edit</span>
</a><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/editbtn.blade.php ENDPATH**/ ?>