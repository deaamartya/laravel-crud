<?php $__env->startSection('Judul','Data Detail Penjualan'); ?>
<?php $__env->startSection('headlink'); ?>
  <link href="/admin/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <style type="text/css">
    .btn-group-sm > .btn-icon-split.btn .icon, .btn-icon-split.btn-sm .icon {
      padding: 2px 5px;
    };
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h3 class="m-0 font-weight-bold text-primary">Data Detail Penjualan</h3>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama Product</th>
              <th>Jumlah</th>
              <th>Harga Jual</th>
              <th>Diskon</th>
              <th>Total Harga</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>ID</th>
              <th>Nama Product</th>
              <th>Jumlah</th>
              <th>Harga Jual</th>
              <th>Diskon</th>
              <th>Total Harga</th>
            </tr>
          </tfoot>
          <tbody>
            <?php $__currentLoopData = $saledets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($c -> nota_id); ?></td>
              <td><?php echo e($c -> product_name); ?></td>
              <td><?php echo e($c -> quantity); ?></td>
              <td><?php echo e($c -> selling_price); ?></td>
              <td><?php echo e($c -> discount); ?></td>
              <td><?php echo e($c ->total_price); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bottom'); ?>
<script>
  $(document).ready( function () {
    $('#dataTable').DataTable();
});
</script>
<script src="/admin/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="/admin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<?php echo $__env->yieldContent('bottomlink'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/saledet/list.blade.php ENDPATH**/ ?>