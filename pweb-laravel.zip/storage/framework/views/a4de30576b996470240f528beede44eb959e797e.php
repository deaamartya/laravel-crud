<?php $__env->startSection('judultable','Penjualan'); ?>

<?php $__env->startSection('btn-insert'); ?>
<a href="<?php echo e(route('sale.create')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>Nama Customer</th>
  <th>Nama User</th>
  <th>Tanggal Penjualan</th>
  <th>Total Pembelian</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c -> nota_id); ?></td>
	<td><?php echo e($c -> c_fullname); ?></td>
  <td><?php echo e($c -> u_fullname); ?></td>
  <td><?php echo e($c -> nota_date); ?></td>
  <td><?php echo e($c -> total_payment); ?></td>
  <td>
    <a href="<?php echo e(route('sale.show', $c->nota_id)); ?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-30">
          <i class="material-icons">visibility</i>
        </span>
        <span class="text">Lihat Invoice</span>
    </a>
    <?php echo $__env->make('actbtn', 
    array(
    'editlink' => 'sale.edit',
    'id' => $c -> nota_id,
    'dellink' => 'sale.destroy',
    'name' => $c -> nota_id,
    'entity' => 'penjualan',
    'Entity' => 'Penjualan'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\crud\resources\views/sale/list.blade.php ENDPATH**/ ?>