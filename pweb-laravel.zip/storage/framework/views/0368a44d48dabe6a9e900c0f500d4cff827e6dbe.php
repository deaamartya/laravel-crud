	
	<div class='ctrl'>
	  <div class='ctrl__button ctrl__button--decrement'>&ndash;</div>
	  <div class='ctrl__counter'>
	    <input style="width: 100%; border:0px; -moz-appearance:textfield;" class='ctrl__counter-input quantity' type='number' value='1' oninput="myFunction(<?php echo e($id); ?>)" name='quantity[<?php echo e($id); ?>]' min='1' id='jumlah<?php echo e($id); ?>' required max='<?php echo e($stock); ?>'>
	    <div class='ctrl__counter-num'>0</div>
	  </div>
	  <div class='ctrl__button ctrl__button--increment'>+</div>
	</div>
<?php echo $__env->make('spinnermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views/components/inputspinner.blade.php ENDPATH**/ ?>