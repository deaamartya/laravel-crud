<?php $__env->startSection('headlink'); ?>
	<link href="/admin/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <style type="text/css">
    .btn-group-sm > .btn-icon-split.btn .icon, .btn-icon-split.btn-sm .icon {
      padding: 2px 5px;
    };
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
  		<h3 class="m-0 font-weight-bold text-primary">Data <?php echo $__env->yieldContent('judultable'); ?></h3>
      	<?php echo $__env->yieldContent('btn-insert'); ?>
      		<button class="btn btn-primary">Tambah <?php echo $__env->yieldContent('judultable'); ?></button>
		</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <?php echo $__env->yieldContent('header'); ?>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <?php echo $__env->yieldContent('header'); ?>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
            <?php echo $__env->yieldContent('data'); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bottom'); ?>
<script src="/admin/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="/admin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="/admin/js/demo/datatables-demo.js"></script>
<?php echo $__env->yieldContent('bottomlink'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views/selectmaster.blade.php ENDPATH**/ ?>