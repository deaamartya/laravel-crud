<?php $__env->startSection('judultable','Produk'); ?>

<?php $__env->startSection('btn-insert'); ?>
<a href="<?php echo e(route('product.create')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>Nama Kategori</th>
  <th>Nama Produk</th>
  <th>Harga</th>
  <th>Stok</th>
  <th>Deskripsi</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c -> product_id); ?></td>
	<td><?php echo e($c -> category_name); ?></td>
  <td><?php echo e($c -> product_name); ?></td>
  <td><?php echo e($c -> product_price); ?></td>
  <td><?php echo e($c -> product_stock); ?></td>
  <td><?php echo e($c -> explanation); ?></td>
  <td>
    <?php echo $__env->make('actbtn', 
    array(
    'editlink' => 'product.edit',
    'id' => $c -> product_id,
    'dellink' => 'product.destroy',
    'name' => $c -> product_name,
    'entity' => 'produk',
    'Entity' => 'Produk'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\crud\resources\views/product/list.blade.php ENDPATH**/ ?>