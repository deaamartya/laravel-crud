<?php $__env->startSection('kontent'); ?>
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
		  		<h3 class="m-0 font-weight-bold text-primary">Tambahkan Data User</h3>
		    </div>
			<div class="card-body" style="margin: 10px; padding: 20px;">

				<form method="post" action="<?php echo e(route('user.store')); ?>" id="catForm">
					<?php echo csrf_field(); ?>
					<div class="row">
					<div class="col-6" style="margin-bottom: 10px; padding-left: 0px;">
						<?php $__env->startComponent('components.formfield'); ?>
							
						    <?php $__env->slot('icon'); ?> perm_identity <?php $__env->endSlot(); ?>
						    <?php $__env->slot('type'); ?> text <?php $__env->endSlot(); ?>
						    <?php $__env->slot('onkey'); ?> return lettersOnly(event) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('name'); ?> first_name <?php $__env->endSlot(); ?>
						    <?php $__env->slot('req'); ?> true <?php $__env->endSlot(); ?>
						    <?php $__env->slot('maxl'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('max'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('value'); ?> <?php $__env->endSlot(); ?>
						    <?php $__env->slot('label'); ?> Nama Depan <?php $__env->endSlot(); ?>
						    <?php $__env->slot('help'); ?> Masukkan huruf(Aa-Zz) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('char'); ?> 0 / 50 <?php $__env->endSlot(); ?>
					    <?php echo $__env->renderComponent(); ?>
					</div>
					<div class="col-6" style="margin-bottom: 10px; padding-left: 0px;">
					    <?php $__env->startComponent('components.formfield'); ?>
					    	
						    <?php $__env->slot('icon'); ?> perm_identity <?php $__env->endSlot(); ?>
						    <?php $__env->slot('type'); ?> text <?php $__env->endSlot(); ?>
						    <?php $__env->slot('onkey'); ?> return lettersOnly(event) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('name'); ?> last_name <?php $__env->endSlot(); ?>
						    <?php $__env->slot('req'); ?> true <?php $__env->endSlot(); ?>
						    <?php $__env->slot('maxl'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('max'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('value'); ?> <?php $__env->endSlot(); ?>
						    <?php $__env->slot('label'); ?> Nama Belakang <?php $__env->endSlot(); ?>
						    <?php $__env->slot('help'); ?> Masukkan huruf(Aa-Zz) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('char'); ?> 0 / 50 <?php $__env->endSlot(); ?>
					    <?php echo $__env->renderComponent(); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-4" style="margin-bottom: 10px; padding-left: 0px;">
					    <label class="mdc-text-field mdc-text-field--outlined mdc-text-field--with-leading-icon" style="width: 100%;">
						  <i class="material-icons mdc-text-field__icon mdc-text-field__icon--leading">phone</i>
						  <input type="text" class="mdc-text-field__input" aria-labelledby="my-label-id" name="phone" required onkeypress="return numOnly(event)" style="-moz-appearance : textfield;" maxlength="12" placeholder="8xxxxxxxxxxx" minlength="10">
						  <div class="mdc-notched-outline">
						   <div class="mdc-notched-outline__leading"></div>
						    <div class="mdc-notched-outline__notch">
						      <span class="mdc-floating-label" id="my-label-id">Nomor Telepon</span>
						    </div>
						    <div class="mdc-notched-outline__trailing"></div>
						  </div>
						</label>
						<div class="mdc-text-field-helper-line">
						  <div class="mdc-text-field-helper-text" id="my-helper-id" aria-hidden="true">Masukkan angka setelah +62</div>
						  <div class="mdc-text-field-character-counter">0 / 12</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-6" style="margin-bottom: 10px; padding-left: 0px;">
					    <?php $__env->startComponent('components.formfield'); ?>
					    	
						    <?php $__env->slot('icon'); ?> mail_outline <?php $__env->endSlot(); ?>
						    <?php $__env->slot('type'); ?> email <?php $__env->endSlot(); ?>
						    <?php $__env->slot('onkey'); ?>  <?php $__env->endSlot(); ?>
						    <?php $__env->slot('name'); ?> email <?php $__env->endSlot(); ?>
						    <?php $__env->slot('req'); ?> true <?php $__env->endSlot(); ?>
						    <?php $__env->slot('maxl'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('max'); ?> 50 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('value'); ?> <?php $__env->endSlot(); ?>
						    <?php $__env->slot('label'); ?> Email <?php $__env->endSlot(); ?>
						    <?php $__env->slot('help'); ?> Masukkan email Anda <?php $__env->endSlot(); ?>
						    <?php $__env->slot('char'); ?> 0 / 50 <?php $__env->endSlot(); ?>
					    <?php echo $__env->renderComponent(); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-4" style="margin-bottom: 10px; padding-left: 0px;">
					    <?php $__env->startComponent('components.formfield'); ?>
						    <?php $__env->slot('icon'); ?> my_location <?php $__env->endSlot(); ?>
						    <?php $__env->slot('type'); ?> password <?php $__env->endSlot(); ?>
						    <?php $__env->slot('onkey'); ?> <?php $__env->endSlot(); ?>
						    <?php $__env->slot('name'); ?> password <?php $__env->endSlot(); ?>
						    <?php $__env->slot('req'); ?> true <?php $__env->endSlot(); ?>
						    <?php $__env->slot('maxl'); ?> 8 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('max'); ?> 8 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('value'); ?> <?php $__env->endSlot(); ?>
						    <?php $__env->slot('label'); ?> Password <?php $__env->endSlot(); ?>
						    <?php $__env->slot('help'); ?> Masukkan password (max. 8 karakter) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('char'); ?> 0 / 8 <?php $__env->endSlot(); ?>
					    <?php echo $__env->renderComponent(); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-5" style="margin-bottom: 10px; padding-left: 0px;">
					    <?php $__env->startComponent('components.formfield'); ?>
						    <?php $__env->slot('icon'); ?> location_city <?php $__env->endSlot(); ?>
						    <?php $__env->slot('type'); ?> text <?php $__env->endSlot(); ?>
						    <?php $__env->slot('onkey'); ?> return lettersOnlySpace(event) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('name'); ?> job_status <?php $__env->endSlot(); ?>
						    <?php $__env->slot('req'); ?> true <?php $__env->endSlot(); ?>
						    <?php $__env->slot('maxl'); ?> 15 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('max'); ?> 15 <?php $__env->endSlot(); ?>
						    <?php $__env->slot('value'); ?> <?php $__env->endSlot(); ?>
						    <?php $__env->slot('label'); ?> Job Status <?php $__env->endSlot(); ?>
						    <?php $__env->slot('help'); ?> Masukkan huruf(Aa-Zz) <?php $__env->endSlot(); ?>
						    <?php $__env->slot('char'); ?> 0 / 15 <?php $__env->endSlot(); ?>
					    <?php echo $__env->renderComponent(); ?>
					</div>
				</div>

					<h6 class="m-10 font-italic text-danger">(*) Wajib diisi</h3>
					<button type="submit" class="btn btn-primary btn-block">Submit</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inputmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views//user/form.blade.php ENDPATH**/ ?>