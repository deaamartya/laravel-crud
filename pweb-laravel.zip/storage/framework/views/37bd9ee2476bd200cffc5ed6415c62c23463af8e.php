<?php $__env->startSection('judultable','User'); ?>

<?php $__env->startSection('btn-insert'); ?>
<a href="<?php echo e(route('user.create')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>First Name</th>
  <th>Last Name</th>
  <th>Phone</th>
  <th>Email</th>
  <th>Job Status</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c->user_id); ?></td>
	<td><?php echo e($c->first_name); ?></td>
	<td><?php echo e($c->last_name); ?></td>
	<td>0<?php echo e($c->phone); ?></td>
	<td><?php echo e($c->email); ?></td>
	<td><?php echo e($c->job_status); ?></td>
  <td>
    <?php echo $__env->make('actbtn', 
    array(
    'editlink' => 'user.edit',
    'id' => $c -> user_id,
    'dellink' => 'user.destroy',
    'name' => $c -> first_name,
    'entity' => 'user',
    'Entity' => 'User'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\crud\resources\views/user/list.blade.php ENDPATH**/ ?>