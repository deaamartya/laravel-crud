<?php $__env->startSection('Judul','Data Customer'); ?>
<?php $__env->startSection('judultable','Customer'); ?>

<?php if(session('type') == 3): ?>
  <?php $__env->startSection('btn-insert'); ?>
  <a href="<?php echo e(route('customer.create')); ?>">
    <button class="btn btn-primary">Tambah Customer</button>
  </a>
  <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>First Name</th>
  <th>Last Name</th>
  <th>Phone</th>
  <th>Email</th>
  <th>Street</th>
  <th>City</th>
  <th>State</th>
  <th>Zip Code</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c->customer_id); ?></td>
	<td><?php echo e($c->first_name); ?></td>
	<td> 
    <?php if($c->last_name == ""): ?>
    -
    <?php else: ?>
    <?php echo e($c->last_name); ?>

    <?php endif; ?>
  </td>
	<td>0<?php echo e($c->phone); ?></td>
	<td><?php echo e($c->email); ?></td>
	<td><?php echo e($c->street); ?></td>
	<td><?php echo e($c->city); ?></td>
	<td><?php echo e($c->state); ?></td>
	<td><?php echo e($c->zip_code); ?></td>
  <td>
    <?php if(session('type') == 3): ?>
      <?php echo $__env->make('editbtn', 
      array(
      'editlink' => 'customer.edit',
      'id' => $c -> customer_id), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(session('type') == 1): ?>
    <?php echo $__env->make('delbtn', 
    array(
    'id' => $c -> customer_id,
    'dellink' => 'customer'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahankonten'); ?>
  <?php if(session('deleted')): ?>
    <script>
      Swal.fire(
        'Delete Success!',
        "Customer <?php echo e(@session('deleted')); ?> telah dihapus",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('inserted')): ?>
    <script>
      Swal.fire(
        'Insert Success!',
        "Customer <?php echo e(@session('inserted')); ?> berhasil ditambahkan",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('edited')): ?>
    <script>
      Swal.fire(
        'Edit Success!',
        "Data customer dengan ID <?php echo e(@session('edited')); ?> berhasil diubah",
        'success'
      )
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomlink'); ?>
<script>
$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    Swal.fire({
    title: 'Apakah kamu yakin?',
    text: "Customer yang dihapus tidak dapat dikembalikan!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ya, Saya Yakin!',
    cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            window.location.href = url;
        }
        else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Customer tidak dihapus',
          'error'
        )
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/cust/list.blade.php ENDPATH**/ ?>