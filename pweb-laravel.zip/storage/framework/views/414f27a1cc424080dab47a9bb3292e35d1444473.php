<?php $__env->startSection('Judul','Data User'); ?>
<?php $__env->startSection('judultable','User'); ?>

<?php if(session('type') == 1): ?>
  <?php $__env->startSection('btn-insert'); ?>
  <a href="<?php echo e(route('user.create')); ?>">
    <button class="btn btn-primary">Tambah User</button>
  </a>
  <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>First Name</th>
  <th>Last Name</th>
  <th>Phone</th>
  <th>Email</th>
  <th>Job Status</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c->user_id); ?></td>
	<td><?php echo e($c->first_name); ?></td>
	<td><?php if($c->last_name == ""): ?>
    -
    <?php else: ?>
    <?php echo e($c->last_name); ?>

    <?php endif; ?></td>
	<td>0<?php echo e($c->phone); ?></td>
	<td><?php echo e($c->email); ?></td>
	<td><?php echo e($c->nama_job); ?></td>
  <td>
      <?php if(session('type') == 1): ?>
      <?php echo $__env->make('editbtn', 
      array(
      'editlink' => 'user.edit',
      'id' => $c -> user_id), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('delbtn', 
      array(
      'id' => $c -> user_id,
      'dellink' => 'user'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tambahankonten'); ?>
  <?php if(session('deleted')): ?>
    <script>
      Swal.fire(
        'Delete Success!',
        "User <?php echo e(@session('deleted')); ?> telah dihapus",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('inserted')): ?>
    <script>
      Swal.fire(
        'Insert Success!',
        "User <?php echo e(@session('inserted')); ?> berhasil ditambahkan",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('edited')): ?>
    <script>
      Swal.fire(
        'Edit Success!',
        "Data user dengan ID <?php echo e(@session('edited')); ?> berhasil diubah",
        'success'
      )
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomlink'); ?>
<script>
$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    Swal.fire({
    title: 'Apakah kamu yakin?',
    text: "User yang dihapus tidak dapat dikembalikan!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ya, Saya Yakin!',
    cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            window.location.href = url;
        }
        else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'User tidak dihapus',
          'error'
        )
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/user/list.blade.php ENDPATH**/ ?>