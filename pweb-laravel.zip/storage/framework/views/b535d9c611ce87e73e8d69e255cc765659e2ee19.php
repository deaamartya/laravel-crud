<?php $__env->startSection('Judul','Data Penjualan'); ?>
<?php $__env->startSection('judultable','Penjualan'); ?>

<?php if(session('type') == 3): ?>
  <?php $__env->startSection('btn-insert'); ?>
  <a href="<?php echo e(route('sale.create')); ?>">
    <button class="btn btn-primary">Tambah Penjualan</button>
  </a>
  <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>Nama Customer</th>
  <th>Nama User</th>
  <th>Tanggal Penjualan</th>
  <th>Total Pembelian</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <div class="row">
  	<td><?php echo e($c -> nota_id); ?></td>
  	<td><?php echo e($c -> c_fullname); ?></td>
    <td><?php echo e($c -> u_fullname); ?></td>
    <td><?php echo e($c -> nota_date); ?></td>
    <td><?php echo e($c -> total_payment); ?></td>
    <td>
      <?php if((session('type') == 3) || ((session('type') == 2) || (session('type') == 1))): ?>
      <a class="btn btn-success btn-icon-split btn-sm" href="<?php echo e(route('sale.show',$c -> nota_id)); ?>">
          <span class="icon text-white-30">
            <i class="material-icons">visibility</i>
          </span>
          <span class="text">Lihat Invoice</span>
      </a>
      <?php endif; ?>
      <?php if(session('type') == 3): ?>
        <?php echo $__env->make('editbtn', 
        array(
        'editlink' => 'sale.edit',
        'id' => $c -> nota_id), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php elseif(session('type') == 1): ?>
      <?php echo $__env->make('delbtn', 
      array(
      'id' => $c -> nota_id,
      'dellink' => 'sale'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
    </td>
  </div>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tambahankonten'); ?>
  <?php if(session('deleted')): ?>
    <script>
      Swal.fire(
        'Delete Success!',
        "Penjualan <?php echo e(@session('deleted')); ?> telah dihapus",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('inserted')): ?>
    <script>
      Swal.fire(
        'Insert Success!',
        "Penjualan <?php echo e(@session('inserted')); ?> berhasil ditambahkan",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('edited')): ?>
    <script>
      Swal.fire(
        'Edit Success!',
        "Data penjualan dengan ID <?php echo e(@session('edited')); ?> berhasil diubah",
        'success'
      )
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomlink'); ?>
<script>
$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    Swal.fire({
    title: 'Apakah kamu yakin?',
    text: "Penjualan yang dihapus tidak dapat dikembalikan!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ya, Saya Yakin!',
    cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            window.location.href = url;
        }
        else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Penjualan tidak dihapus',
          'error'
        )
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/sale/list.blade.php ENDPATH**/ ?>