<?php $__env->startSection('tmbhstyle'); ?>
.bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
    width: 100%;
}
.btn-light {
	height: 55px;
}
.btn{
	line-height:2;
}
<?php $__env->stopSection(); ?>
<?php $__env->startSection('kontent'); ?>
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
		  		<h3 class="m-0 font-weight-bold text-primary">Edit Data Detail Penjualan</h3>
		    </div>
			<div class="card-body" style="margin: 20px;">
				<form method="post" action="/saledet/update/<?php echo e($nota_id); ?>/<?php echo e($product_id); ?>" id="catForm">
					<?php echo csrf_field(); ?>
					<h6>ID Penjualan*</h6>
					<div class="row" style="margin-bottom: 20px">
						<div class="col-9">
							<select class="selectpicker" data-live-search="true" name="nota_id" required>
								<option disabled="true">Pilih nota</option>
								<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(($c->nota_id) == $nota_id): ?>
									<option value="<?php echo e($c -> nota_id); ?>" selected><?php echo e($c -> nota_id); ?></option>
									<?php else: ?>
									<option value="<?php echo e($c -> nota_id); ?>"><?php echo e($c -> nota_id); ?></option>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
					
					<h6>Nama Produk*</h6>
					<div class="row">
						<div class="col-6">
						<select class="selectpicker" data-live-search="true" name="product_id" required style="width: 100%;">
								<option disabled="true" selected="">Pilih produk</option>
								<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(($c -> product_id) == $product_id): ?>
									<option value="<?php echo e($c -> product_id); ?>" selected><?php echo e($c -> product_name); ?></option>
									<?php else: ?>
									<option value="<?php echo e($c -> product_id); ?>"><?php echo e($c -> product_name); ?></option>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="col-2">
						    <label class="mdc-text-field mdc-text-field--outlined" style="width: 100%;">
							  <input type="number" class="mdc-text-field__input" aria-labelledby="my-label-id" name="quantity" required onkeypress="return numOnly(event)" max="99" min="1" value="<?php echo e($saledet->quantity); ?>">
							  <div class="mdc-notched-outline">
							   <div class="mdc-notched-outline__leading"></div>
							    <div class="mdc-notched-outline__notch">
							      <span class="mdc-floating-label" id="my-label-id">Jumlah</span>
							    </div>
							    <div class="mdc-notched-outline__trailing"></div>
							  </div>
							</label>
							<div class="mdc-text-field-helper-line">
							  <div class="mdc-text-field-helper-text" id="my-helper-id" aria-hidden="true">Masukkan jumlah (max. 10 angka)</div>
							</div>
						</div>
						<div class="col-4">
						    <label class="mdc-text-field mdc-text-field--outlined" style="width: 100%;">
							  <input id="currency" type="text" class="mdc-text-field__input" aria-labelledby="my-label-id" name="discount" required onkeypress="return numOnly(event)" maxlength="16" value="<?php echo e($saledet->discount); ?>">
							  <div class="mdc-notched-outline">
							   <div class="mdc-notched-outline__leading"></div>
							    <div class="mdc-notched-outline__notch">
							      <span class="mdc-floating-label" id="my-label-id">Discount</span>
							    </div>
							    <div class="mdc-notched-outline__trailing"></div>
							  </div>
							</label>
							<div class="mdc-text-field-helper-line">
							  <div class="mdc-text-field-helper-text" id="my-helper-id" aria-hidden="true">Masukkan diskon (max. 10 angka)</div>
							</div>
						</div>
					</div>


					<h6 class="m-10 font-italic text-danger">(*) Wajib diisi</h6>
					<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectfield', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\crud\resources\views/saledet/edit.blade.php ENDPATH**/ ?>