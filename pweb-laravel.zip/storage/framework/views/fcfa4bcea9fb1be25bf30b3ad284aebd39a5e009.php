<form id="switch<?php echo e($id); ?>" action="<?php echo e(url($dellink.'/updateStatus/'.$id)); ?>" method="post">
	<?php echo csrf_field(); ?>
	<div class="custom-control custom-switch">
		<?php if($status == 1): ?>
		<input type="checkbox" class="custom-control-input" id="c<?php echo e($id); ?>" onclick="submit(<?php echo e($id); ?>)" name="status<?php echo e($id); ?>" value="<?php echo e($status); ?>" checked>
		<?php else: ?>
		<input type="checkbox" class="custom-control-input" id="c<?php echo e($id); ?>" onclick="submit(<?php echo e($id); ?>)" name="status<?php echo e($id); ?>" value="<?php echo e($status); ?>">
		<?php endif; ?>
		<?php if($status == 1): ?>
		<label class="custom-control-label" for="c<?php echo e($id); ?>">Nonaktifan</label>
		<?php else: ?>
		<label class="custom-control-label" for="c<?php echo e($id); ?>">Aktifkan</label>
		<?php endif; ?>
	</div>
</form><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/updatebtn.blade.php ENDPATH**/ ?>