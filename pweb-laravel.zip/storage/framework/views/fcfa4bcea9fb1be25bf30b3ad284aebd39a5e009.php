<div class="custom-control custom-switch">
	<?php if($status == 1): ?>
	<input type="checkbox" class="custom-control-input switch" id="<?php echo e($id); ?>" checked>
	<?php else: ?>
	<input type="checkbox" class="custom-control-input switch" id="<?php echo e($id); ?>">
	<?php endif; ?>
	<?php if($status == 1): ?>
	<label id="label<?php echo e($id); ?>" class="custom-control-label" for="<?php echo e($id); ?>">Nonaktifan</label>
	<?php else: ?>
	<label id="label<?php echo e($id); ?>" class="custom-control-label" for="<?php echo e($id); ?>">Aktifkan</label>
	<?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/updatebtn.blade.php ENDPATH**/ ?>