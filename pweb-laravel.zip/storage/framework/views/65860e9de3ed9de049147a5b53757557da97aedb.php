<?php $__env->startSection('tmbhatas'); ?>
<!-- <style>
    form{
        margin: 20px 0;
    }
    form input, button{
        padding: 5px;
    }
    table{
        width: 100%;
        margin-bottom: 20px;
    border-collapse: collapse;
    }
    table, th, td{
        border: 1px solid #cdcdcd;
    }
    table th, table td{
        padding: 10px;
        text-align: left;
    }
</style> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('kontent'); ?>
<div class="row">
  <div class="col">
    <div class="card">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
          <h3 class="m-0 font-weight-bold text-primary">Tambahkan Data Detail Penjualan</h3>
        </div>
      <div class="card-body" style="margin: 20px;">
        <form method="post" action="<?php echo e(route('sale.store')); ?>" id="catForm">
          <?php echo csrf_field(); ?>
          <h6>Nama Customer*</h6>
          <div class="row" style="margin-bottom: 20px">
            <div class="col-9">
            <select class="selectpicker" data-live-search="true" name="customer_id" required>
                <option disabled="true" selected="">Pilih customer</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c -> customer_id); ?>"><?php echo e($c -> first_name); ?> <?php echo e($c -> last_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
          </div>

          <h6>Nama User*</h6>
          <div class="row" style="margin-bottom: 20px">
            <div class="col-9">
            <select class="selectpicker" data-live-search="true" name="user_id" required>
                <option disabled="true" selected="">Pilih user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c -> user_id); ?>"><?php echo e($c -> first_name); ?> <?php echo e($c -> last_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              </div>
          </div>

          <input type="button" class="add-row" value="Add Row">

          <h6>Nama Product</h6>
          <div class="row" style="margin-bottom: 20px">
            <div class="col-12">
            <select class="selectpicker" data-live-search="true" name="product_id" required id="idproduk[]">
                <option disabled="true" selected="">Pilih produk</option>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c -> product_id); ?>"><?php echo e($c -> product_name); ?></option>
                <?php echo e($id = $c -> product_id); ?>

                <?php echo e($name[$id] = $c -> product_name); ?>

                <?php echo e($price[$id] = $c -> product_price); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
          </div>

          <table>
              <thead>
                  <tr>
                      <th>Select</th>
                      <th>Name</th>
                      <th>Email</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td><input type="checkbox" name="record"></td>
                      <td>Peter Parker</td>
                      <td>peterparker@mail.com</td>
                  </tr>
              </tbody>
          </table>
          
          </form>
        </div>
      </div>
    </div>
  </div>
<form>
    
    
    
<button type="button" class="delete-row">Delete Row</button>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tambahan'); ?>
<!-- <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script> -->
<script>
    $(document).ready(function(){
        $(".add-row").click(function(){
            var idproduct = $("#idproduk").val();
            // <?php $id = $idproduk; ?>;
            var name = "<?php echo $name; ?>";
            var price = "<?php echo $price; ?>";
            var markup = "<tr><td><input type='checkbox' name='record'></td><td>" + idproduct + "</td><td>" + name + "</td></tr>";
            $("table tbody").append(markup);
        });
        
        // Find and remove selected table rows
        $(".delete-row").click(function(){
            $("table tbody").find('input[name="record"]').each(function(){
              if($(this).is(":checked")){
                    $(this).parents("tr").remove();
                }
            });
        });
    });    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectfield', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\crud\resources\views/sale/cart.blade.php ENDPATH**/ ?>