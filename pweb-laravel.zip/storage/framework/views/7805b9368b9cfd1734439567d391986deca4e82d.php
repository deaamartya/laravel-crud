<?php $__env->startSection('Judul','Data Produk'); ?>
<?php $__env->startSection('judultable','Produk'); ?>

<?php if(session('type') == 4): ?>
<?php $__env->startSection('btn-insert'); ?>
<a href="<?php echo e(route('product.create')); ?>">
  <button class="btn btn-primary">Tambah Produk)</button>
</a>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('header'); ?>
  <th>ID</th>
  <th>Kategori</th>
  <th>Nama Produk</th>
  <th>Harga</th>
  <th>Stok</th>
  <th>Deskripsi</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($c -> product_id); ?></td>
	<td><?php echo e($c -> category_name); ?></td>
  <td><?php echo e($c -> product_name); ?></td>
  <td class="price" align="right"><?php echo e($c -> product_price); ?></td>
  <td align="center"><?php echo e($c -> product_stock); ?></td>
  <td><?php if($c -> explanation == ""): ?> - <?php else: ?> <?php echo e($c -> explanation); ?> <?php endif; ?></td>
  <td>
    <?php if(session('type') == 4): ?>
      <?php echo $__env->make('editbtn', 
      array(
      'editlink' => 'product.edit',
      'id' => $c -> product_id), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(session('type') == 1): ?>
    <?php echo $__env->make('delbtn', 
    array(
    'id' => $c -> product_id,
    'dellink' => 'product'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahankonten'); ?>
  <?php if(session('deleted')): ?>
    <script>
      Swal.fire(
        'Delete Success!',
        "Produk <?php echo e(@session('deleted')); ?> telah dihapus",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('inserted')): ?>
    <script>
      Swal.fire(
        'Insert Success!',
        "Produk <?php echo e(@session('inserted')); ?> berhasil ditambahkan",
        'success'
      )
    </script>
  <?php endif; ?>
  <?php if(session('edited')): ?>
    <script>
      Swal.fire(
        'Edit Success!',
        "Data produk dengan ID <?php echo e(@session('edited')); ?> berhasil diubah",
        'success'
      )
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottomlink'); ?>
<script type="text/javascript" src="<?php echo e(asset('/js/autoNumeric.js')); ?>"></script>
<script>
  $(document).ready(function(){
    $('.price').autoNumeric('init', {aSep: '.', aDec: ',', aSign: 'Rp ', aPad: false, nBracket: '(,)', lZero: 'deny'});
    $('#dataTable').dataTable({
       columns: [
                {name: 'product_id', width:'5%'},
                {name: 'category_name', width:'10%'},
                {name: 'product_name', width:'25%'},
                {name: 'product_price', width:'15%'},
                {name: 'product_stock', width:'10%'},
                {name: 'explanation', width:'20%'},
                {name: 'action', orderable: false, searchable: false, width:'15%'},
             ],
      order: [[0, 'asc']]
    });
  });

$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    Swal.fire({
    title: 'Apakah kamu yakin?',
    text: "Produk yang dihapus tidak dapat dikembalikan!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ya, Saya Yakin!',
    cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.value) {
            window.location.href = url;
        }
        else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Produk tidak dihapus',
          'error'
        )
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudgit\pweb-laravel\resources\views/product/list.blade.php ENDPATH**/ ?>