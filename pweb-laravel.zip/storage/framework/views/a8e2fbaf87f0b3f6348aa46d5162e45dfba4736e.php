<?php $__env->startSection('kontent'); ?>
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
		  		<h3 class="m-0 font-weight-bold text-primary">Edit Data Penjualan</h3>
		    </div>
			<div class="card-body" style="margin: 20px;">
				<form method="post" action="<?php echo e(route('sale.update', $sale->nota_id)); ?>" id="catForm">
					<?php echo method_field('PUT'); ?>
					<?php echo csrf_field(); ?>
					<h6>Nama Customer*</h6>
					<div class="row" style="margin-bottom: 20px">
						<div class="col-9">
						<select class="selectpicker" data-live-search="true" name="customer_id" required>
								<option disabled="true">Pilih customer</option>
								<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($c -> customer_id == $sale -> customer_id): ?>
								<option value="<?php echo e($c -> customer_id); ?>" selected><?php echo e($c -> first_name); ?> <?php echo e($c -> last_name); ?></option>
								<?php else: ?>
								<option value="<?php echo e($c -> customer_id); ?>"><?php echo e($c -> first_name); ?> <?php echo e($c -> last_name); ?></option>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							</div>
					</div>
					<h6>Nama User*</h6>
					<div class="row" style="margin-bottom: 20px">
						<div class="col-9">
						<select class="selectpicker" data-live-search="true" name="user_id" required>
								<option disabled="true">Pilih user</option>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($c -> user_id == $sale -> user_id): ?>
								<option value="<?php echo e($c -> user_id); ?>" selected><?php echo e($c -> first_name); ?> <?php echo e($c -> last_name); ?></option>
								<?php else: ?>
								<option value="<?php echo e($c -> user_id); ?>"><?php echo e($c -> first_name); ?> <?php echo e($c -> last_name); ?></option>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							</div>
					</div>
					<div class="row" style="margin-bottom: 10px">
						<div class="col-3">
						    <label class="mdc-text-field mdc-text-field--outlined" style="width: 100%;">
							  <input id="currency" type="text" class="mdc-text-field__input" aria-labelledby="my-label-id" name="total_payment" required onkeypress="return numOnly(event)" maxlength="16" value="<?php echo e($sale -> total_payment); ?>">
							  <div class="mdc-notched-outline">
							   <div class="mdc-notched-outline__leading"></div>
							    <div class="mdc-notched-outline__notch">
							      <span class="mdc-floating-label" id="my-label-id">Total Pembayaran</span>
							    </div>
							    <div class="mdc-notched-outline__trailing"></div>
							  </div>
							</label>
							<div class="mdc-text-field-helper-line">
							  <div class="mdc-text-field-helper-text" id="my-helper-id" aria-hidden="true">Masukkan harga (max. 10 angka)</div>
							</div>
							
						</div>
					</div>
					<div class="row" style="margin-bottom: 5px">
						<div class="col-3">
							<?php $__env->startComponent('components.formfield'); ?>
							    <?php $__env->slot('icon'); ?> calendar_today <?php $__env->endSlot(); ?>
							    <?php $__env->slot('type'); ?> date <?php $__env->endSlot(); ?>
							    <?php $__env->slot('onkey'); ?>  <?php $__env->endSlot(); ?>
							    <?php $__env->slot('name'); ?> nota_date <?php $__env->endSlot(); ?>
							    <?php $__env->slot('req'); ?> true <?php $__env->endSlot(); ?>
							    <?php $__env->slot('maxl'); ?>  <?php $__env->endSlot(); ?>
							    <?php $__env->slot('max'); ?>  <?php $__env->endSlot(); ?>
							    <?php $__env->slot('value'); ?> <?php echo e($sale -> nota_date); ?>  <?php $__env->endSlot(); ?>
							    <?php $__env->slot('label'); ?> Tanggal Pembelian <?php $__env->endSlot(); ?>
							    <?php $__env->slot('help'); ?> Masukkan tanggal pembelian <?php $__env->endSlot(); ?>
							    <?php $__env->slot('char'); ?> <?php $__env->endSlot(); ?>
						    <?php echo $__env->renderComponent(); ?>
						</div>
					</div>

					<h6 class="m-10 font-italic text-danger">(*) Wajib diisi</h6>
					<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('selectfield', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\crud\resources\views//sale/edit.blade.php ENDPATH**/ ?>