<label class="mdc-text-field mdc-text-field--outlined mdc-text-field--with-leading-icon">
  <i class="material-icons mdc-text-field__icon mdc-text-field__icon--leading"><?php echo e($icon); ?></i>
  <input type="number" class="mdc-text-field__input" aria-labelledby="my-label-id" name="<?php echo e($name); ?>" required="<?php echo e($req); ?>" onkeypress="<?php echo e($onkey); ?>" value="<?php echo e($value); ?>" style="-moz-appearance : textfield;" maxlength="<?php echo e($maxl); ?>" pattern="[0-9]*">
  <div class="mdc-notched-outline">
   <div class="mdc-notched-outline__leading"></div>
    <div class="mdc-notched-outline__notch">
      <span class="mdc-floating-label" id="my-label-id"><?php echo e($label); ?></span>
    </div>
    <div class="mdc-notched-outline__trailing"></div>
  </div>
</label>
<div class="mdc-text-field-helper-line">
  <div class="mdc-text-field-helper-text" id="my-helper-id" aria-hidden="true"><?php echo e($help); ?></div>
  <div class="mdc-text-field-character-counter"><?php echo e($char); ?></div>
</div><?php /**PATH C:\xampp1\htdocs\crud\resources\views/components/numformfield.blade.php ENDPATH**/ ?>